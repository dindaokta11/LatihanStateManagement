package com.example.latihanstatemenagement

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
